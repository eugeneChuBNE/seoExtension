// content.js
function getImagesAndLinks() {
    const contentArea = document.querySelector('#vnx_post_content');
    if (!contentArea) {
      return { images: [], links: [] };
    }
  
    const images = Array.from(contentArea.querySelectorAll('img')).map(img => {
      const figure = img.closest('figure');
      const caption = figure ? figure.querySelector('figcaption') : null;
      
      return {
        id: img.id || null,
        alt_text: img.alt || '',
        url: img.src || '',
        name: img.getAttribute('data-name') || '',
        format: img.src ? img.src.split('.').pop() : '',
        caption: caption ? caption.textContent : ''
      };
    });
  
    const links = Array.from(contentArea.querySelectorAll('a')).map(link => ({
      link_id: link.id || null,
      anchor: link.textContent || '',
      url: link.href || '',
      is_external: link.hostname !== location.hostname,
      is_nofollow: link.rel.includes('nofollow'),
      is_new_tab: link.target === '_blank'
    }));
  
    return { images, links };
  }
  
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'getImagesAndLinks') {
      sendResponse(getImagesAndLinks());
    }
  });
  